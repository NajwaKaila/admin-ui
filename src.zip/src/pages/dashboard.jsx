import React, { useContext, useEffect, useState } from 'react';
import MainLayout from "../components/Layouts/MainLayout";
import Card from "../components/Elements/Card";
import CardBalance from "../components/Elements/Fragments/CardBalance";
import CardGoal from "../components/Elements/Fragments/CardGoal";
import CardUpcomingBill from '../components/Elements/Fragments/CardUpcomingBill';
import CardRecentTransaction from '../components/Elements/Fragments/CardRecentTransaction';
import CardStatistic from '../components/Elements/Fragments/CardStatistic';
import CardExpenseBreakdown from '../components/Elements/Fragments/CardExpenseBreakdown';
import { transactions, 
    bills, 
    expensesBreakdowns,
    balances,
    goals,
    expensesStatistics,
} from "../data";
import { goalService } from "../services/dataService";
import { AuthContext } from "../context/authContext";
import AppSnackbar from '../components/Elements/AppSnackbar';

function dashboard() {
  const [goals, setGoals] = useState({});
  const { logout } = useContext(AuthContext)

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const handleCloseSnackbar = () => {
    setSnackbar((prev) => ({
      ...prev,
      open: false,
    }));
  };

  const fetchGoals = async () => {
    try {
      const data = await goalService();
      setGoals(data);
    } catch (err) {
      setSnackbar({
        open: true,
        message: err.msg || "Login gagal",
        severity: "error",
      });
      if (err.status === 401) {
        logout();
      }
    }
  };

  useEffect(() => {
    fetchGoals();
  }, []);

  return (
    <>
    <MainLayout>
        <div className="grid sm:grid-cols-12 gap-6">
          <div className="sm:col-span-4">
            <CardBalance data={balances} />
          </div>
          <div className="sm:col-span-4">
            <CardGoal data={goals} />
          </div>
          <div className="sm:col-span-4">
            <CardUpcomingBill data={bills} />
          </div>
          <div className="sm:col-span-4 sm:row-span-2">
            <CardRecentTransaction data={transactions} />
          </div>
          <div className="sm:col-span-8">
            <CardStatistic data={expensesStatistics} />
          </div>
          <div className="sm:col-span-8">
            <CardExpenseBreakdown data={expensesBreakdowns} />
          </div>
        </div>

				<AppSnackbar
          open={snackbar.open}
          message={snackbar.message}
          severity={snackbar.severity}
          onClose={handleCloseSnackbar}
        />
      </MainLayout>
    </> 
  );
}

export default dashboard